/*
 * Created on 27.02.2004
 */
package de.psi.ema.client.intern;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Vector;

import javax.swing.UIManager;

import org.apache.log4j.xml.DOMConfigurator;

import psi.pm.security.HashUtils;
import de.guibuilder.framework.GuiComponent;
import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiSelect;
import de.guibuilder.framework.GuiSession;
import de.guibuilder.framework.GuiUtil;
import de.psi.ema.clientif.DirectoryServiceIF;
import de.psi.ema.clientif.InternalClientIF;
import de.psi.ema.util.Const;
import electric.registry.Registry;
import electric.xml.Document;
import electric.xml.Element;
import electric.xml.Elements;

/**
 * Main-Class f�r das Starten des internen Clients.
 * <ul>
 * <li>Logger initialisieren
 * <li>Konfigurations-Datei "InternalClientConfig.xml" einlesen
 * <li>System-Properties setzen, wenn welche eingetragen
 * <li>Menge der SOAP-Hosts ermitteln f�r Auswahl-Combo/Listbox
 * <li>Login-Dialog starten
 * <li>SOAP-Bindung durchf�hren
 * <li>Login beim Service
 * <li>Weiter bei MainController (Hauptfenster)
 * </ul>
 * 
 * @author pkoeker
 */
public class ClientSession {
	private String sHost;

	private String loginName;

	private static ClientSession me;

	private InternalClientIF srv;

	private DirectoryServiceIF dsrv;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger
			.getLogger(ClientSession.class);

	// private Constructor
	private ClientSession() {
	}

	public static ClientSession getInstance() {
		return me;
	}

	public static void main(String[] args) {
	   // 1. logger
		DOMConfigurator.configure("log4j/Log4JConfigInternalClient.xml");
		logger.info("InternalClient started #################");
		try {
			 UIManager.setLookAndFeel("net.java.plaf.windows.WindowsLookAndFeel");
		} catch ( Exception ex ) {
		    logger.error(ex.getMessage(), ex);
		}	    
		me = new ClientSession();
		//me.korrRiser();
		me.init();
	}

	//	private void korrRiser() {
	//		try {
	//			IPL pl = new PLAutocommit("PLConfigRISER.xml");
	//			File f = new File("ExportCity.xml");
	//			Document doc = new Document(f);
	//			JDataSet dsKorr = new JDataSet(doc);
	//			Iterator it = dsKorr.getChildRows();
	//			while (it.hasNext()) {
	//				JDataRow rowKorr = (JDataRow) it.next();
	//				long ags = rowKorr.getValueLong("CityId");
	//				JDataSet dsCity = pl.getDataset("City", ags);
	//				int anzPlz = -1;
	//				if (dsCity.getRowCount() == 0) {
	//					rowKorr.setInserted(true);
	//					anzPlz = 0;
	//				} else {
	//					anzPlz = dsCity.getRow().getChildRowCount("PostalCode");
	//				}
	//				if (anzPlz == 0) {
	//					Iterator itPC = rowKorr.getChildRows("PostalCode");
	//					if (itPC != null) {
	//						while (itPC.hasNext()) {
	//							JDataRow rowPC = (JDataRow) itPC.next();
	//							rowPC.setInserted(true);
	//						}
	//					}
	//					Iterator itPR = rowKorr.getChildRows("CityPrice");
	//					if (itPR != null) {
	//						while (itPR.hasNext()) {
	//							JDataRow rowPR = (JDataRow) itPR.next();
	//							rowPR.setInserted(true);
	//						}
	//					}
	//				}
	//			}
	//			JDataSet dsChanges = dsKorr.getChanges();
	//			int cnt = pl.setDataset(dsChanges);
	//			System.out.println(cnt);
	//		} catch (Exception ex) {
	//			ex.printStackTrace();
	//		}
	//	}

	private void init() {
		try {
			// 2. Config
			Document doc = new Document(new File("InternalClientConfig.xml"));
			Element root = doc.getRoot();
			// 2.1 System-Props setzen
			{
				Elements sysEles = root.getElements("SystemProperty");
				while (sysEles.hasMoreElements()) {
					Element ele = sysEles.next();
					String name = ele.getAttribute("name");
					String value = ele.getAttribute("value");
					System.setProperty(name, value);
				}
			}
			// 2.2 Menge der Hosts-Eintr�ge ermitteln f�r Combo-/Listbox
			LinkedHashMap map = new LinkedHashMap();
			Vector displayMem = new Vector();
			Vector valueMem = new Vector();
			{
				Elements connectEles = root.getElements("Connection");
				while (connectEles.hasMoreElements()) {
					Element tmpEle = connectEles.next();
					ConfigEntry entry = new ConfigEntry(tmpEle);
					map.put(entry.title, entry);
					displayMem.add(entry.title);
					valueMem.add(entry.url);
				}
			}
			// 3. Login
			GuiFactory fact = GuiFactory.getInstance();
			GuiUtil.setDocumentBase("gui/");
			boolean isExit = false;
			do { // so lange das Logindialog zeigen, bis man das Programm nicht
				 // beendet wird.
				try {
					// 3.1 Login-Dialog
					boolean isLoggedIn = false;
					String error = null;
					GuiDialog dia = (GuiDialog) fact.createWindow("Login.xml");
					if (loginName == null)
						loginName = this.getLoginUser();
					dia.setValue("loginName", loginName);
					GuiComponent comp = dia.getGuiComponent("password");
					GuiSelect sele = (GuiSelect) dia.getGuiComponent("host");
					sele.setItems(displayMem);
					//sele.setMap(???)
					if (sHost != null)
						sele.setSelectedItem(sHost);
					dia.getComponent().setVisible(true);
					comp.requestFocus();
					dia.getComponent().setVisible(false);
					if (dia.showDialog()) {
						loginName = dia.getRootPane().getMainPanel()
								.getGuiComponent("loginName").getValue()
								.toString();
						String password = dia.getRootPane().getMainPanel()
								.getGuiComponent("password").getValue()
								.toString();
						String enc = HashUtils.createSecurityHexToken(password);
						
						String sSelect = dia.getValue("host") != null ? dia.getValue("host").toString() : null;
						if (sSelect == null)
							throw new LoginException(
									"Please select a server to connect to!");
						ConfigEntry selEntry = (ConfigEntry) map.get(sSelect);
						sHost = selEntry.url;
						if (sHost.equals("(please select)"))
							throw new LoginException(
									"Please select a server to connect to!");

						Element urlClientEle = root.getElement("URL_Client");
						String sUrlClient = urlClientEle.getTextString();

						Element urlDirEle = root.getElement("URL_Dir");
						String sUrlDir = urlDirEle.getTextString();

						logger.debug("InternalClient binding to: " + sHost
								+ sUrlClient);
						// 3.2 Binding an Service
						if (sHost.startsWith("file://")) {
							srv = (InternalClientIF) Registry.bind(sHost,
									InternalClientIF.class);
							dsrv = (DirectoryServiceIF) Registry.bind(sHost,
									DirectoryServiceIF.class);
						} else {
							srv = (InternalClientIF) Registry.bind(sHost
									+ sUrlClient, InternalClientIF.class);
							dsrv = (DirectoryServiceIF) Registry.bind(sHost
									+ sUrlDir, DirectoryServiceIF.class);
						}
						if (srv.getVersion().equals(Const.VERSION) == false) {
							String msg = "Client Server Version Mismatch. Server: "
									+ srv.getVersion()
									+ " Client: "
									+ Const.VERSION;
							logger.error(msg);
							//throw new LoginException(msg);
							GuiUtil.showMessage(null, "Internal Client Login",
									"Warn", msg);
						}

						logger.debug("Binding established!");
						// 3.3 Perform login
						String username = srv.login(loginName, enc);
						// 3.4 Main Window
						MainController.getInstance().showWindow(selEntry);
					} else {
						isExit = true;
					}
				} catch (LoginException ex) {
					logger.error("Login", ex);
					GuiUtil.showMessage(null, "eMA Administration Login",
							"Error", ex.getMessage());
				} catch (Exception ex) {
					logger.error("Login", ex);
					
					if (ex.getMessage() != null && ex.getMessage().indexOf("Login") != -1)
						GuiUtil.showMessage(null, "eMA Administration Login",
								"Error", "Wrong username or password!");
					else
						GuiUtil.showEx(ex);
				}
			} while (!isExit);

		} catch (Exception ex) {
			logger.error("Fehler beim Initialisieren", ex);
			ex.printStackTrace();
		}
		System.exit(0);
	}

	/**
	 * Liefert den Benutzernamen das am Betriebssystem angemeldeten Nutzers
	 * 
	 * @return
	 */
	final String getLoginUser() {
		return GuiSession.getInstance().getUsername();
	}

	final InternalClientIF getInternalService() {
		return srv;
	}

	final DirectoryServiceIF getDirectoryService() {
		return dsrv;
	}

	class ConfigEntry {
		String url;
		String title;
		String image;

		ConfigEntry(Element ele) {
			this.url = ele.getElement("URL").getTextString();
			if (url.endsWith("/") == false) {
				this.url = this.url + "/";
			}
			this.title = ele.getElement("Title").getTextString();
			this.image = ele.getElement("Image").getTextString();
		}
	}
}