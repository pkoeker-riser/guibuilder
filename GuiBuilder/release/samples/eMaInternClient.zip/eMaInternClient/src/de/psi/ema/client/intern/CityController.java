/*
 * Created on 27.01.2005
 */
package de.psi.ema.client.intern;

import java.io.File;

import de.guibuilder.framework.GuiComponent;
import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiTableRow;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;
import de.jdataset.JDataSet;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.InternalClientIF;
import de.psi.ema.domain.City;
import electric.xml.Document;

/**
 * Gui-Controller f�r City.xml, CityZIP.xml und CityPrice.xml
 * 
 * @author PKOEKER
 */
public final class CityController {
    private GuiFactory fact;

    private GuiWindow win;

    private InternalClientIF srv;

    private String loginUser;

    private static org.apache.log4j.Logger logger = org.apache.log4j.Logger
            .getLogger(CityController.class);

    CityController(final String loginUser) {
        this.loginUser = loginUser;
        this.fact = GuiFactory.getInstance();
        // Services
        this.srv = ClientSession.getInstance().getInternalService();
        this.show();
    }

    private void show() {
        try {
            win = fact.createWindow("City.xml");
            win.setController(this);
            win.reset();
            win.show();
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    // USER-Events
    /**
     * Neue Gemeinde anlegen.
     */
    public final void newCity(GuiUserEvent event) {
        GuiWindow win = event.window;
        win.reset();
        try {
            City city = srv.newCity();
            JDataSet ds = city.getDataSet();
            win.setDatasetValues(ds);
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    /**
     * Suchen einer Gemeinde �ber die eingegebenen Suchbegriffe Name, ZIP,
     * CityId
     * 
     * @param event
     */
    public final void searchCity(GuiUserEvent event) {
        GuiWindow win = event.window;
        String such = win.getValue("suchbegriff").toString();
        String zip = win.getValue("zip").toString();
        String cityId = win.getValue("cityId").toString();
        try {
	        JDataSet ds = srv.searchCity(such, zip, cityId);
	        ds.setUsername(this.loginUser);
	        win.reset();
	        win.setDatasetValues(ds);
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    /**
     * Schreibt �nderungen an Gemeinden zur�ck.
     * 
     * @param event
     */
    public final void saveCity(GuiUserEvent event) {
        JDataSet ds = win.getDatasetValues();
        if (ds.hasChanges()) {
            try {
                JDataSet dsChanges = ds.getChanges();
                int cnt = srv.setCity(dsChanges);
                ds.commitChanges();
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
                GuiUtil.showEx(ex);
            }
        }
    }

    /**
     * Es wird mit der Maus oder Tastatur eine andere Gemeinde selektiert
     * 
     * @param event
     */
    public final void cityRowSelected(GuiUserEvent event) {
        GuiWindow window = event.window;
        window.getAction("isave").setEnabled(true);
        window.getAction("tsave").setEnabled(true);
        window.getAction("idelete").setEnabled(true);
    }

    /**
     * L�scht eine Zeile in der Tabelle mit den Gemeinden; f�r das L�schen in
     * der Datenbank mu� anschlie�end "save" ausgef�hrt werden.
     * 
     * @param event
     */
    public final void deleteCity(GuiUserEvent event) {
        GuiWindow window = event.window;
        GuiTable tbl = window.getRootPane().getCurrentTable();
        tbl.deleteRow();
    }
    /**
     * Zeigt den Dialog mit den Postleitzahlen zu der selektierten Gemeinde an.
     * @param event
     */
    public final void postalCodes_City(GuiUserEvent event) {
        try {
            GuiTable tbl = event.window.getRootPane().getCurrentTable();
            int trow = tbl.getSelectedRow();
            String ags = tbl.getRow(trow).getValue("cityId").toString();
            String cityname = tbl.getRow(trow).getValue("cityName").toString();
            long cityId = Convert.toLong(ags);
            JDataSet dsZIP = srv.getPostalCodes_City(cityId);
            dsZIP.setUsername(this.loginUser);
            GuiDialog dia = (GuiDialog) fact.createWindow("CityZIP.xml");
            dia.setController(new CityZIPPriceController());
            dia.setValue("cityId", ags);
            dia.setValue("cityName", cityname);
            dia.setDatasetValues(dsZIP);
            if (dia.showDialog()) {
                JDataSet ds = dia.getDatasetValues();
                if (ds.hasChanges()) {
                    JDataSet dsChanges = ds.getChanges();
                    try {
                        int cnt = srv.setPostalCodes_City(dsChanges);
                        ds.commitChanges();
                    } catch (Exception ex) {
                        logger.error(ex.getMessage(), ex);
                        GuiUtil.showEx(ex);
                    }
                }
            }
        } catch (Exception ex) {
            logger.error("PLZ/City", ex);
            GuiUtil.showEx(ex);
        }
    }

    /**
     * Preise mit G�ltigkeitszeitpunkt
     * 
     * @param event
     */
    public final void priceCity(GuiUserEvent event) {
        // Preise eingeben
        try {
            // 1. Dialog erzeugen / Controller registrieren
            GuiDialog dia = (GuiDialog) fact.createWindow("CityPrice.xml");
            dia.setController(new CityZIPPriceController());
            // 2. Attribut "element=" der Tabelle setzen
            GuiTable tbl = event.window.getRootPane().getCurrentTable();
            int index = tbl.getSelectedRow();
            GuiTableRow tRow = tbl.getRow(index);
            dia.setRootElementName("City["
                    + Convert.toString(tRow.getModelElementNumber()) + "]");
            String eleName = ".CityPrice";
            GuiComponent tblPrice = dia.getGuiComponent("price");
            tblPrice.setElementName(eleName);
            // 3 AGS f�r neue Zeilen versorgen
            dia.setValue("cityName", tRow.getValue("cityName"));
            dia.setValue("cityId", tRow.getValue("cityId"));
            // 4. Daten aus Hauptfenster umt�ten
            JDataSet ds = event.window.getDatasetValues();
            dia.setDatasetValues(ds);
            // 5. Anzeigen
            if (dia.showDialog()) {
                // 6. Zur�ckt�ten
                JDataSet dsDia = dia.getDatasetValues();
                event.window.setDatasetValues(dsDia);
                if (dsDia.hasChanges()) {
                    JDataSet dsChanges = dsDia.getChanges();
                    srv.setCity(dsChanges);
                    dsDia.commitChanges();
                }
            }
        } catch (Exception ex) {
            logger.error("City/Price", ex);
            GuiUtil.showEx(ex);
        }
    }

    // Replication
    public final void exportCity(GuiUserEvent event) {
        try {
            JDataSet ds = srv.exportCityZIPPrice();
            File f = new File("ExportCity.xml");
            Document doc = ds.getXml();
            doc.write(f);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            GuiUtil.showEx(ex);
        }
    }

    public final void importCity(GuiUserEvent event) {

    }
}