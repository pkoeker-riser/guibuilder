/*
 * Created on 17.01.2005
 */
package de.psi.ema.client.intern;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;
import java.util.StringTokenizer;

import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.event.GuiUserEvent;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.InternalClientIF;

/**
 * Importiert die CSV-Daten in die Preisliste, die mit
 * "showPriceListFromTo" exportiert wurden.
 * @author PKOEKER
 */
public class ImportCityPriceController {
   private static ImportCityPriceController me;
   private InternalClientIF srv;

   private ImportCityPriceController() {
      srv = ClientSession.getInstance().getInternalService();
   }

   public static ImportCityPriceController getInstance() {
      if (me == null) {
         synchronized (ImportCityPriceController.class) {
            me = new ImportCityPriceController();
         }
      }
      return me;
   }
   
   void show() {
      try {
         GuiDialog dia = (GuiDialog)GuiFactory.getInstance().createWindow("ImportCityPrice.xml");
         dia.setController(this);
         if (dia.showDialog()) {
            String filename = dia.getValue("filename").toString();
            File f = new File(filename);
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String line = null;
            String head = br.readLine(); // Zeile 0
            int ll=1;
            while ((line = br.readLine()) != null) {
               ll++;
               StringTokenizer toks = new StringTokenizer(line,";");
               int cnt = 0;
               long ags = -1;
               String cityName = null;
               double price = 0.0;
               String date = null;
               while (toks.hasMoreTokens()) {
                  String tok = toks.nextToken();
                  if (tok.startsWith("\"")) {
                     tok = tok.substring(1);
                  }
                  if (tok.endsWith("\"")) {
                     tok = tok.substring(0, tok.length()-1);
                  }
                  switch(cnt) {
                     case 0:
                        ags = Convert.toLong(tok);
                        break;
                     case 1:
                        cityName = tok;
                        break;
                     case 2:
                        if (tok.equals("null") == false) {
                           price = Convert.toDouble(tok);
                        }
                        break;
                     case 3:
                        if (tok.equals("null") == false) {
                           date = tok;
                        }
                        break;
                  }
                  cnt++;
               } // Wend toks
               if (ags != 0 && price != 0.0) {
                  
                  if (date == null) { // Insert
                     int anz = this.insertPrice(ags, price, "31.1.2004");
                     if (anz == 0) {
                        //anz = this.updatePrice(ags, price, "31.1.2004");
                     }
                  } else { // Update
                     int anz = this.updatePrice(ags, price, date);
                     if (anz == 0) {
                        anz = this.insertPrice(ags, price, "31.1.2004");
                     }
                  }
               }
            } // Wend line
          System.out.println(ll);
         }
      } catch (Exception ex) {
         GuiUtil.showEx(ex);
      }
   }
   private int insertPrice(long ags, double price, String date) {
      Date d = Convert.toDate(date);
      try {
         int cnt = this.srv.insertPrice(ags, price, d);
         return cnt;
      } catch (Exception ex) {
         //GuiUtil.showEx(ex); // Daten sind schon drin
         return -1;
      }
      
   }
   private int updatePrice(long ags, double price, String date) {
      Date d = Convert.toDate(date);
      try {
         int cnt = this.srv.updatePrice(ags, price, d);
         return cnt;
      } catch (Exception ex) {
         GuiUtil.showEx(ex);
         return -1;
      }
   }

   public final void selectFile(GuiUserEvent event) {
      String[] res = GuiUtil.fileOpenDialog(event.window, "Open CSV-File", null, "*.csv");
      if (res != null) {
         event.window.setValue("filename", res[0]);
      }
   }
}