/*
 * Created on 04.05.2005
 * (C) 2005 PSI Information Management GmbH 
 */
package de.psi.ema.client.intern;

import junit.framework.TestCase;

/**
 * @author KKNOBLOCH
 */
public class TestLoginException extends TestCase {

    /*
     * Class under test for void LoginException()
     */
    public void testLoginException() {
        LoginException ex = new LoginException();
        assertNull(ex.getMessage());
    }

    /*
     * Class under test for void LoginException(String)
     */
    public void testLoginExceptionString() {
        String exMessage ="TestTestTestTest";
        LoginException ex = new LoginException(exMessage);
        assertEquals(exMessage, ex.getMessage());
    }

    /*
     * Class under test for void LoginException(String, Throwable)
     */
    public void testLoginExceptionStringThrowable() {
        String exMessageInner = "Inner Login Exception";
        String exMessageOuter = "Outer Login Exception";
        LoginException exInner = new LoginException(exMessageInner);
        LoginException exOuter = new LoginException(exMessageOuter,exInner);
        assertNotNull(exOuter.getCause());
        assertEquals(exMessageInner,exOuter.getCause().getMessage());
        assertEquals(exMessageOuter,exOuter.getMessage());
        
    }

    /*
     * Class under test for void LoginException(Throwable)
     */
    public void testLoginExceptionThrowable() {
        String exMessage = "Inner Login Exception";
        LoginException exInner = new LoginException(exMessage);
        LoginException exOuter = new LoginException(exInner);
        assertNotNull(exOuter.getCause());
        assertEquals(exMessage,exOuter.getCause().getMessage());
    }

}
