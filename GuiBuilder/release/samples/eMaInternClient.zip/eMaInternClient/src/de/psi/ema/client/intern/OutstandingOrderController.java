/*
 * Created on 04.02.2005
 */
package de.psi.ema.client.intern;

import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;
import de.jdataset.JDataSet;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.InternalClientIF;
import de.psi.ema.domain.OrderItem;
import de.psi.ema.util.Const;

/**
 * Dialog-Controller f�r OutstandingOrder.xml unter Mitbenutzung von EntryDetail.xml.
 * @author PKOEKER
 */
public class OutstandingOrderController {
	private GuiFactory fact;
	private GuiWindow win;
	private InternalClientIF srv;
	private String loginUser;
	
	private static org.apache.log4j.Logger logger =
		org.apache.log4j.Logger.getLogger(OutstandingOrderController.class);

	OutstandingOrderController(String loginUser) {
		this.loginUser = loginUser;
		this.fact = GuiFactory.getInstance();
		// Services
		this.srv = ClientSession.getInstance().getInternalService();
		this.show();
	}
	private void show() {
		try {
			win = fact.createWindow("OutstandingOrder.xml");
			win.setController(this);
			JDataSet ds = this.srv.getAuftragUeberfaellig(1);
			ds.setUsername(this.loginUser);
			win.setDatasetValues(ds);
			win.show();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void auftragPosiDetail(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int row = tbl.getSelectedRow();
			long entryId = Convert.toLong(tbl.getCellValue(0));
			OrderItem item = srv.getOrderItem(entryId);
			GuiWindow detailWin = fact.createWindow("EntryDetail.xml");
			detailWin.setRootElementName("Pre_Entry");
			detailWin.setDatasetValues(item.getDataSet());
			detailWin.setUserObject(item);
			detailWin.show();

		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void auftragPosiError(GuiUserEvent event) {
		try {
			JDataSet ds = event.window.getDatasetValues();
			OrderItem item = (OrderItem)event.window.getUserObject();
			item.setStatus(Const.ENTRY_STATUS_FEHLER);
			srv.setOrderItem(item);
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}
}
