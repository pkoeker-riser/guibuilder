/*
 * Created on 22.03.2005
 * (C) 2005 PSI Information Management GmbH 
 */
package de.psi.ema.client.intern;

/**
 * @author KKNOBLOCH
 */
public final class TestRunnerEMaInternClient {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(AllTests.suite());
    }
}
