/*
 * Created on 04.02.2005
 */
package de.psi.ema.client.intern;

import psi.pm.security.HashUtils;
import de.guibuilder.framework.GuiCombo;
import de.guibuilder.framework.GuiComponent;
import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiTableRow;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiChangeEvent;
import de.guibuilder.framework.event.GuiUserEvent;
import de.jdataset.JDataSet;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.InternalClientIF;

/**
 * Dialog-Controller f�r Customer.xml und CustomerOverview.xml.
 * @author PKOEKER
 */
public final class CustomerController {
	private GuiFactory fact;
	private GuiWindow win;
	private InternalClientIF srv;
	private String loginUser;
	
	private static org.apache.log4j.Logger logger =
		org.apache.log4j.Logger.getLogger(CustomerController.class);

	CustomerController(String loginUser) {
		this.loginUser = loginUser;
		this.fact = GuiFactory.getInstance();
		// Services
		this.srv = ClientSession.getInstance().getInternalService();
		this.show();
	}
	private void show() {
		try {
			win = fact.createWindow("Customer.xml");
			win.setController(this);
			
			GuiCombo combo = (GuiCombo)win.getGuiComponent("cmbCustomerType");
			combo.setItems(srv.getCustomerTypes());
			
			combo =	(GuiCombo) win.getGuiComponent("param.cmbReceiverCodec");
			combo.setItems(srv.getSupportedCustomerCodecs());

			combo =	(GuiCombo) win.getGuiComponent("param.cmbOrderPlacementResultCodec");
			combo.setItems(srv.getSupportedOrderPlacementResultCodecs());

			combo =	(GuiCombo) win.getGuiComponent("param.cmbReceiverPortalCodec");
			combo.setItems(srv.getSupportedCustomerCodecs());
			
			combo =	(GuiCombo) win.getGuiComponent("param.cmbTransmitterCodec");
			combo.setItems(srv.getSupportedCustomerCodecs());

			combo =	(GuiCombo) win.getGuiComponent("param.cmbTransmitterPortalCodec");
			combo.setItems(srv.getSupportedCustomerCodecs());

			combo =	(GuiCombo) win.getGuiComponent("param.cmbTransmitter");
			combo.setItems(srv.getSupportedTransmitter());
		
			win.reset();
			win.setActionState(GuiWindow.STATE_EMPTY);

			win.show();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void searchCustomer(GuiUserEvent event) {
		try {
			event.window.cursorWait();
			GuiWindow window = event.window;
			JDataSet ds = srv.getCustomers();
			ds.setUsername(this.loginUser);
			GuiDialog dia =
				(GuiDialog) fact.createWindow("CustomerOverview.xml");
			dia.setController(this);
			dia.setDatasetValues(ds);
			event.window.cursorDefault();
			if (dia.showDialog()) {
				GuiTable tbl = dia.getRootPane().getCurrentTable();
				long custId = Convert.toLong(tbl.getCellValue(0));
				this.displayCustomer(window, custId);
			}
		} catch (Exception ex) {
			event.window.cursorDefault();
			logger.error("Search Customer", ex);
			GuiUtil.showEx(ex);
		}
	}
	private void displayCustomer(GuiWindow window, long customerId) {
	   try {
			window.cursorWait();
			JDataSet dsCust = srv.getCustomer(customerId);
			dsCust.setUsername(this.loginUser);
			window.reset();
			window.setDatasetValues(dsCust);
			win.setActionState(GuiWindow.STATE_OLD);
			this.makeZmrCustomer(window, dsCust.getRow().getValueBool("bmi_customer"));
			window.cursorDefault();
      } catch (Exception ex) {
          window.cursorDefault();
          GuiUtil.showEx(ex);
      }
	}
	public final void saveCustomer(GuiUserEvent event) {
		try {
			GuiWindow window = event.window;
			JDataSet ds = window.getDatasetValues();
			if (ds.hasChanges()) {
				event.window.cursorWait();
				event.window.verify();
				boolean b = ds.verify();
				if (!b) {
				   String s = ds.getValidationError();
				   GuiUtil.showMessage(event.window, "Validation Error", "Error", s);
				   return;
				}
				JDataSet dsChanges = ds.getChanges();
				srv.setCustomer(dsChanges);
				window.commitChanges();
				ds.commitChanges();
				window.setActionState(GuiWindow.STATE_SAVED);
				event.window.cursorDefault();
			}
		} catch (Exception ex) {
			event.window.cursorDefault();
			logger.error("Save Customer", ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void newCustomer(GuiUserEvent event) {
		try {
			GuiWindow window = event.window;
			window.reset();
			JDataSet ds = srv.newCustomer();
			ds.setUsername(this.loginUser);
			window.setDatasetValues(ds);
			window.setActionState(GuiWindow.STATE_NEW);
			this.makeZmrCustomer(window, false);
		} catch (Exception ex) {
			logger.error("New Customer", ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void deleteCustomer(GuiUserEvent event) {
		if (!GuiUtil.okCancelMessage(event.window, "Delete Customer", "Are you sure you want to delete this Customer?")) return;
		try {
			event.window.cursorWait();
			GuiWindow window = event.window;
			JDataSet ds = window.getDatasetValues();
			ds.setDeleted(true);
			srv.setCustomer(ds);
			window.reset();
			window.setActionState(GuiWindow.STATE_EMPTY);
			this.makeZmrCustomer(window, false);
			event.window.cursorDefault();
		} catch (Exception ex) {
		    event.window.cursorDefault();
			logger.error("Delete Customer", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * F5
	 * @param event
	 */
	public final void reloadCustomer(GuiUserEvent event) {
		try {
			event.window.cursorWait();
			long customerId = Convert.toLong(event.window.getValue("customerId").toString());
			this.displayCustomer(event.window, customerId);
			event.window.setActionState(GuiWindow.STATE_OLD);
			event.window.cursorDefault();
		} catch (Exception ex) {
			event.window.cursorDefault();
			logger.error("Reload Customer", ex);
			GuiUtil.showEx(ex);
		}		
	}
	/**
	 * Dialog zum �ndern des Passwords der Mitarbeiter
	 * @param event
	 */
	public final void userPassword(GuiUserEvent event) {
		try {
			GuiDialog dia = (GuiDialog) fact.createWindow("Password.xml");
			boolean ok = false;
			while (ok == false) {
				if (dia.showDialog()) {
					String p1 =
						dia
							.getRootPane()
							.getMainPanel()
							.getValue("p1")
							.toString();
					String p2 =
						dia
							.getRootPane()
							.getMainPanel()
							.getValue("p2")
							.toString();
					if (p1.equals(p2) && p1.length() >= 5) {
						ok = true;
						GuiWindow win = event.window;
						GuiTable tbl = win.getRootPane().getCurrentTable();
						GuiTableRow trow = tbl.getRow(tbl.getSelectedRow());
						String crypt = HashUtils.createSecurityHexToken(p1);
						trow.setValue("password", crypt);
						trow.setModified(true);
					}
				} else {
					ok = true;
				}
			}
		} catch (Exception ex) {
			logger.error("Set User Password", ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void customerAuskunftAuftrag(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			String s = tbl.getCellValue(0);
			long orderId = Convert.toLong(s);
			GuiWindow win = MainController.getInstance().showAuskunftAuftrag(orderId);
		} catch (Exception ex) {
			logger.error("Customer Auskunft Auftrag", ex);
			GuiUtil.showEx(ex);
		}
	}

	/**
	 * ZMR
	 * @param event
	 */
	public final void zmrCustomerChanged(GuiUserEvent event) {
		GuiChangeEvent che = (GuiChangeEvent)event;
		this.makeZmrCustomer(che.window, che.bValue);
	}
	private void makeZmrCustomer(GuiWindow win, boolean value) {
		String names[] = new String[]{"bmi_userid","bmi_username","bmi_gid","bmi_ouid","bmi_oudomain", "bmi_ou"};
		for (int i = 0; i < names.length; i++) {
			String name = "zmr."+names[i];
			GuiComponent comp = win.getGuiComponent(name);
			comp.setEnabled(value);
			if (value == false) {
				comp.setValue(null);
				comp.setNotnull(false);
			} else {
				comp.setNotnull(true);
			}
		}
	}
}
