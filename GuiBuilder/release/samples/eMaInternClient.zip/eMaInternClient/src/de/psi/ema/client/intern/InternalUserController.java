/*
 * Created on 22.04.2005
 */
package de.psi.ema.client.intern;

import java.util.Iterator;

import psi.pm.security.HashUtils;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;
import de.jdataset.JDataRow;
import de.jdataset.JDataSet;
import de.jdataset.JDataValue;
import de.psi.ema.clientif.InternalClientIF;

/**
 * Controller f�r "InternalUsers.xml"
 * @author PKOEKER
 */
public class InternalUserController {
   private String loginUser;
   private GuiFactory fact;
	private InternalClientIF srv;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger
 		.getLogger(InternalUserController.class);
	
	InternalUserController(String loginUser) {
		this.loginUser = loginUser;
		this.fact = GuiFactory.getInstance();
		// Services
		this.srv = ClientSession.getInstance().getInternalService();
		this.show();
	}
	
	private void show() {
		try {
			GuiWindow win = this.fact.createWindow("InternalUsers.xml");
			win.setController(this);
			JDataSet ds = this.srv.getInternalUsers();
			ds.setUsername(this.loginUser);
			Iterator it = ds.getChildRows();
			if (it != null) {
				while (it.hasNext()) {
					JDataRow row = (JDataRow) it.next();
					JDataValue val = row.getDataValue("password");
					val.setValue("*****");
					val.setModified(false); 
				}
			}
			win.setDatasetValues(ds);
			win.show();			    
		} catch (Exception ex) {
	 		logger.error(ex.getMessage(), ex);
		   GuiUtil.showEx(ex);
		}
	}
 	/**
 	 * Speichert die �nderungen an internen Usern
 	 * @param event
 	 */
 	public final void saveInternalUsers(GuiUserEvent event) {
 		try {
 			event.window.cursorWait();
 			GuiWindow win = event.window;
 			JDataSet ds = win.getDatasetValues();
 			if (ds.hasChanges()) {
 				JDataSet dsChanges = ds.getChanges();
 				Iterator it = dsChanges.getChildRows();
 				while (it.hasNext()) {
 					JDataRow row = (JDataRow) it.next();
 					JDataValue val = row.getDataValue("password");
 					if (val.isModified()) {
 						String crypt = HashUtils.createSecurityHexToken(val.getValue());
 						val.setValue(crypt);
 					}
 				}
 				srv.setInternalUsers(dsChanges);
 			}
			event.window.cursorDefault();
			event.window.hide();
 		} catch (Exception ex) {
 			event.window.cursorDefault();
 			logger.error(ex.getMessage(), ex);
 			GuiUtil.showEx(ex);
 		}
 	}
}
