/*
 * Created on 07.10.2004
 */
package de.psi.ema.client.intern;

import de.guibuilder.framework.GuiCombo;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;

import de.jdataset.JDataSet;
import de.jdataset.ParameterList;
import de.pkjs.util.Convert;

import de.psi.ema.clientif.InternalClientIF;

/**
 * Controller f�r CustomerLog.xml
 * @author PKOEKER
 */
public class CustomerLogController {
	private static CustomerLogController me;
	private GuiFactory fact;
	private GuiWindow win;
	private InternalClientIF srv;

	private static org.apache.log4j.Logger logger =
		org.apache.log4j.Logger.getLogger(CustomerLogController.class);
	
	// private Constructor
	private CustomerLogController() throws Exception {
		fact = GuiFactory.getInstance();
		// Services
		srv = ClientSession.getInstance().getInternalService();
	}
	static synchronized void startup() throws Exception {
		if (me == null) {
			me = new CustomerLogController();
		}
		me.guiInit();
	}
	private void guiInit() throws Exception {
		win = fact.createWindow("CustomerLog.xml");
		win.setController(this);
		// ComboBox Customer mit Werten f�llen
		GuiCombo cmbCustomer = (GuiCombo)win.getGuiComponent("cmbCustomer");
		JDataSet dsCust = srv.getCustomers();
		cmbCustomer.setItems(dsCust);
		customerLog_CustomerChange(null);
		win.reset();
		win.show();
	}
	public final void customerLog_CustomerChange(GuiUserEvent event) {
		long customerId = Convert.toLong(win.getValue("cmbCustomer").toString());
		try {
			JDataSet ds = srv.getEmployees(customerId);
			GuiCombo cmbEmployee = (GuiCombo)win.getGuiComponent("cmbEmployee");
			cmbEmployee.setItems(ds);
		} catch (Exception ex) {
		   GuiUtil.showEx(ex);
		}
	}
	public final void getCustomerLog(GuiUserEvent event) {
		String[] names = new String[]{"cmbCustomer", "cmbEmployee", "fromDate", "toDate", 
				"sessionId", "ipAddress" , "method", "records"};
		ParameterList list = new ParameterList();
		String sql = "SELECT C.CustomerName, E.EmployeeName, CL.* FROM CustomerLog CL";
		sql = sql + " INNER JOIN Customer C ON C.CustomerId = CL.CustomerId";
		sql = sql + " INNER JOIN Employee E ON E.EmployeeId = CL.EmployeeId";
		sql = sql + " WHERE ";
		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			String val = win.getValue(name).toString();
			String ref = win.getGuiComponent(name).getRef();
			if (val.length() > 0) {
				if (name.equals("fromDate") || name.equals("toDate")) {
					list.addParameter(name, Convert.toDate(val));
				} else {
					list.addParameter(name, val);
				}
				sql = sql + ref + " ? AND "; 
			}
		}
		sql = sql.substring(0, sql.length() -4);
		try {
			JDataSet ds = srv.getCustomerLog(sql, list);
			event.window.setDatasetValues(ds);
		} catch (Exception ex) {
			GuiUtil.showEx(ex);
		}
	}
	public final void clearCustomerLog(GuiUserEvent event) {
		event.window.reset();
	}
	public final void windowClosing(GuiUserEvent event) {
		
	}
}
