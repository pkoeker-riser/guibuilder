/*
 * Created on 05.05.2004
 */
package de.psi.ema.client.intern;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * @author Administrator
 */
public class AllTests {

	public static Test suite() {
        // Necessary to work on OSX without the graphics environment .. 
        // harmless elsewhere.
        System.setProperty("java.awt.headless", "true");

        TestSuite suite = new TestSuite("Test for de.psi.ema.client.intern");
		//$JUnit-BEGIN$
        suite.addTestSuite(TestLoginException.class);
		//$JUnit-END$
		return suite;
	}
}
