/*
 * Created on 19.10.2004
 */
package de.psi.ema.client.intern;

/**
 * @author ikunin
 */
public class LoginException extends Exception {

    /**
     * 
     */
    public LoginException() {
        super();
    }

    /**
     * @param message
     */
    public LoginException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public LoginException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param cause
     */
    public LoginException(Throwable cause) {
        super(cause);
    }

}
