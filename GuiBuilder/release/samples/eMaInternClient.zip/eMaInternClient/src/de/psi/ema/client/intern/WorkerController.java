/*
 * Created on 07.02.2005
 */
package de.psi.ema.client.intern;

import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiChangeEvent;
import de.guibuilder.framework.event.GuiUserEvent;
import de.jdataset.JDataSet;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.InternalClientIF;

/**
 * Dialog-Controller f�r Workers.xml, WorkerStatus.xml und WorkerParameter.xml.
 * <p>
 * Dieser Controller wird auch f�r die Registerkarte "Installed Workers" bei den
 * Rechenzentren eingesetzt.
 * 
 * @author PKOEKER
 */
public final class WorkerController {
    private GuiFactory fact;

    private InternalClientIF srv;

    private String loginUser;

    private static org.apache.log4j.Logger logger = org.apache.log4j.Logger
            .getLogger(CustomerController.class);

    WorkerController(boolean show) {
        this.loginUser = ClientSession.getInstance().getLoginUser();
        this.fact = GuiFactory.getInstance();
        // Services
        this.srv = ClientSession.getInstance().getInternalService();
        if (show) {
            this.show();
        }
    }

    private void show() {
        try {
            GuiWindow win = fact.createWindow("Workers.xml");
            win.setController(this);
            JDataSet ds = srv.getWorkers();
            ds.setUsername(this.loginUser);
            win.setDatasetValues(ds);
            win.show();
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    public final void saveWorkers(GuiUserEvent event) {
        GuiWindow win = event.window;
        JDataSet ds = win.getDatasetValues();
        if (ds.hasChanges()) {
            try {
                JDataSet dsChanges = ds.getChanges();
                srv.setWorkers(dsChanges);
            } catch (Exception ex) {
                logger.error("Save Workers", ex);
                GuiUtil.showEx(ex);
            }
        }
        win.setDatasetValues(ds);
        int i = 0;
    }

    /**
     * Alle Worker zur�cksetzen.
     * 
     * @param event
     */
    public final void resetWorkers(GuiUserEvent event) {
        try {
            srv.resetWorkers(this.loginUser);
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    /**
     * Ein einzelnen Worker zur�cksetzen.
     * 
     * @param event
     */
    public final void resetWorker(GuiUserEvent event) {
        GuiTable tbl = event.window.getRootPane().getCurrentTable();
        long workerId = Convert.toLong(tbl.getCellValue(0));
        try {
            boolean ok = srv.resetWorker(workerId, this.loginUser);
            if (ok) {
                String msg = "Worker successfully reseted.";
                GuiUtil.showMessage(event.window, "Reset Worker", "Info", msg);
            } else {
                String msg = "Cannot reset Worker!";
                GuiUtil.showMessage(event.window, "Reset Worker", "Error", msg);
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            GuiUtil.showEx(ex);
        }
    }

    public final void stopWorker(GuiUserEvent event) {
        GuiTable tbl = event.window.getRootPane().getCurrentTable();
        long workerId = Convert.toLong(tbl.getCellValue(0));
        try {
            boolean ok = srv.stopWorker(workerId, this.loginUser);
            if (ok) {
                String msg = "Worker successfully stoped.";
                GuiUtil.showMessage(event.window, "Stop Worker", "Info", msg);
            } else {
                String msg = "Cannot stop Worker!";
                GuiUtil.showMessage(event.window, "Stop Worker", "Error", msg);
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            GuiUtil.showEx(ex);
        }
    }
    /**
     * Wird durch Kontext-Men� beim Worker ausgel�st
     * @param event
     */
    public final void setDebugMode(GuiUserEvent event) {
        GuiChangeEvent ev = (GuiChangeEvent)event;
        GuiTable tbl = event.window.getRootPane().getCurrentTable();
        long workerId = Convert.toLong(tbl.getCellValue(0));
        try {
            boolean ok = srv.setDebugWorker(workerId, ev.bValue, this.loginUser);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            GuiUtil.showEx(ex);
        }
    }
    /**
     * PopupMenu verarzten
     * @param event
     */
    public void selectedWorkerChanged(GuiUserEvent event) {
        GuiTable tbl = event.window.getRootPane().getCurrentTable();
        long workerId = Convert.toLong(tbl.getCellValue(0));
        try {
            boolean debug = srv.isDebugWorker(workerId, this.loginUser);
            event.window.getGuiComponent("mDebugWorker").setValue(new Boolean(debug));
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            GuiUtil.showEx(ex);
        }
    }
    public final void reloadWorkers(GuiUserEvent event) {
        event.window.reset();
        try {
            JDataSet ds = srv.getWorkers();
            ds.setUsername(this.loginUser);
            event.window.setDatasetValues(ds);
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    /**
     * Wir aus dem Dialog "Workers" aufgerufen.
     * 
     * @param event
     */
    public final void workerParameters(GuiUserEvent event) {
        this.editParameter(event.window, "Worker");
    }

    /**
     * Wird aus dem Dialog "Datacenter" aufgerufen.
     * 
     * @param event
     */
    public final void workerParametersDatacenter(GuiUserEvent event) {
        this.editParameter(event.window, "Datacenter.Worker");
    }

    private void editParameter(GuiWindow parentWindow, String path) {
        try {
            JDataSet ds = parentWindow.getDatasetValues();
            GuiDialog dia = (GuiDialog) fact.createWindow("WorkerParameter.xml");
            dia.setController(this);
            GuiTable tbl =  parentWindow.getRootPane().getCurrentTable(); 
            int index = tbl.getSelectedRow();
            if (index == -1)
                return; // leere Tabelle
            int eleNum = tbl.getRow(index).getModelElementNumber(); 
            String eleName = path + "[" + Convert.toString(eleNum) + "]";
            dia.setRootElementName(eleName);
            dia.setDatasetValues(ds);

            if (dia.showDialog()) {
                JDataSet dsModi = dia.getDatasetValues();
                parentWindow.setDatasetValues(dsModi);
            }
        } catch (Exception ex) {
            logger.error("Worker Parameter", ex);
            GuiUtil.showEx(ex);
        }
    }

    public final void workerStatus(GuiUserEvent event) {
        try {
            JDataSet ds = srv.getWorkerStatus();
            ds.setUsername(this.loginUser);
            GuiWindow win = fact.createWindow("WorkerStatus.xml");
            win.setController(this);
            win.setDatasetValues(ds);
            win.show();
        } catch (Exception ex) {
            logger.error("Worker Status", ex);
            GuiUtil.showEx(ex);
        }
    }

    public final void reloadWorkerStatus(GuiUserEvent event) {
        try {
            JDataSet ds = srv.getWorkerStatus();
            ds.setUsername(this.loginUser);
            event.window.reset();
            event.window.setDatasetValues(ds);
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }

    public final void resetInactiveWorkers(GuiUserEvent event) {
        try {
            srv.resetInactiveWorkers(this.loginUser);
        } catch (Exception ex) {
            GuiUtil.showEx(ex);
        }
    }
}