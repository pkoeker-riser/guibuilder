Diese Datei hei�t "AA_Readme.txt", damit sie im Verz. ganz oben steht.

In diesem Verzeichnis m�ssen folgende jar-Archive sein:

- guibuilder.jar (GuiBuilder f�r Swing-Client)
- icons.zip (Oberfl�chen-Icons von Sun f�r GuiBuilder)

Folgende Archive werden von diesem Projekt auc eMaCommon noch ben�tigt:
- jdataset.jar
- GLUE.jar (SOAP)
- log4j-#.#.#.jar