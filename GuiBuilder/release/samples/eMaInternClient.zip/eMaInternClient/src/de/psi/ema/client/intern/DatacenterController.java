/*
 * Created on 07.02.2005
 */
package de.psi.ema.client.intern;

import java.util.Iterator;

import psi.pm.security.HashUtils;
import de.guibuilder.framework.GuiCombo;
import de.guibuilder.framework.GuiComponent;
import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiTab;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiTableRow;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;
import de.jdataset.JDataRow;
import de.jdataset.JDataSet;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.InternalClientIF;
import de.psi.ema.domain.City;
import de.psi.ema.domain.DataCenter;

/**
 * Dialog-Controller f�r Datacenter.xml, DatacenterOverview.xml
 * unter Mitverwendung von CityZip.xml und CityPrice.xml
 * @author PKOEKER
 */
public final class DatacenterController {
	private GuiFactory fact;
	private GuiWindow win;
	private InternalClientIF srv;
	private String loginUser;
	
	private static org.apache.log4j.Logger logger =
		org.apache.log4j.Logger.getLogger(CustomerController.class);

	DatacenterController(String loginUser) {
		this.loginUser = loginUser;
		this.fact = GuiFactory.getInstance();
		// Services
		this.srv = ClientSession.getInstance().getInternalService();
		this.show();
	}
	private void show() {
		try {
			win = fact.createWindow("Datacenter.xml");
			win.setController(this);
			/**
			 * Mapping zwischen Comboboxen und Stammdaten-Dataset
			 */
			{
				GuiCombo combo =
					(GuiCombo) win.getGuiComponent("param.cmbRequestCodecs");
				String[] items = srv.getSupportedDataCenterCodecs();
				combo.setItems(items);
				combo.reset();
			}
			{
				GuiCombo combo =
					(GuiCombo) win.getGuiComponent("param.cmbRequestTrans");
				String[] items = srv.getSupportedTransmitter();
				combo.setItems(items);
				combo.reset();
			}

			{
				GuiCombo combo =
					(GuiCombo) win.getGuiComponent("param.cmbResponseCodecs");
				String[] items = srv.getSupportedDataCenterCodecs();
				combo.setItems(items);
				combo.reset();
			}
			{
				GuiCombo combo =
					(GuiCombo) win.getGuiComponent("param.cmbResponseTrans");
				String[] items = srv.getSupportedTransmitter();
				combo.setItems(items);
				combo.reset();
			}
			{
				GuiTable tbl = (GuiTable)win.getGuiComponent("cost.tblCost");
				JDataSet items = srv.getCustomerTypes();
				tbl.setItems("cmbCustomerType", items);
			}
			// F�r Tab Workers
			WorkerController ctrl = new WorkerController(false);
			GuiTab tab = win.getRootPane().getTabByName("tabWorker");
			tab.setController(ctrl);
			win.setActionState(GuiWindow.STATE_EMPTY);
			win.show();
		} catch (Exception ex) {
			logger.error("Datacenters", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * L�scht ein Rechenzentrum mit all seinen abh�ngigen Daten.
	 * Bei den Orten wird Dcid auf <null> gesetzt.
	 * @param event
	 */
	public final void deleteDC(GuiUserEvent event) {
		if (!GuiUtil.okCancelMessage(event.window, "Delete Data Center", "Are you sure you want to delete this Data Center?")) return;
		try {
			GuiWindow window = event.window;
			JDataSet ds = window.getDatasetValues();
			ds.setDeleted(true);
			srv.setDatacenter(ds);
			window.reset();
			win.setActionState(GuiWindow.STATE_EMPTY);
		} catch (Exception ex) {
			logger.error("Delete Datacenter", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * F5
	 * @param event
	 */
	public final void reloadDatacenter(GuiUserEvent event) {
		try {
			event.window.cursorWait();
			long dcId = Convert.toLong(event.window.getValue("dcId").toString());
			this.displayDatacenter(event, dcId);
			win.setActionState(GuiWindow.STATE_OLD);
			event.window.cursorDefault();
		} catch (Exception ex) {
			event.window.cursorDefault();
			logger.error("Reload Datacenter", ex);
			GuiUtil.showEx(ex);
		}		
	}

	/**
	 * Eingabe Password Employee
	 * @param event
	 */
	public final void dcPassword(GuiUserEvent event) {
		try {
			GuiDialog dia = (GuiDialog) fact.createWindow("Password.xml");
			boolean ok = false;
			while (ok == false) {
				if (dia.showDialog()) {
					String p1 =
						dia
							.getRootPane()
							.getMainPanel()
							.getValue("p1")
							.toString();
					String p2 =
						dia
							.getRootPane()
							.getMainPanel()
							.getValue("p2")
							.toString();
					if (p1.equals(p2) && p1.length() >= 5) {
						ok = true;
						GuiWindow win = event.window;
						String crypt = HashUtils.createSecurityHexToken(p1);
						win.setValue("password", crypt);
					}
				} else {
					ok = true;
				}
			}
		} catch (Exception ex) {
			logger.error("Set DC Password", ex);
			GuiUtil.showEx(ex);
		}

	}
	/**
	 * Zeigt alle Rechenzentren zur Auswahl an.
	 * @param event
	 */
	public final void searchDC(GuiUserEvent event) {
		try {
			event.window.cursorWait();
			GuiWindow window = event.window;
			JDataSet ds = srv.getDatacenters();
			ds.setUsername(this.loginUser);
			GuiDialog dia =
				(GuiDialog) fact.createWindow("DatacenterOverview.xml");
			dia.setController(this);
			dia.setDatasetValues(ds);
			event.window.cursorDefault();
			if (dia.showDialog()) {
				GuiTable tbl = dia.getRootPane().getCurrentTable();
				long dcId = Convert.toLong(tbl.getCellValue(0));
				this.displayDatacenter(event, dcId);
			}
		} catch (Exception ex) {
			event.window.cursorDefault();
			logger.error("Search Datacenter", ex);
			GuiUtil.showEx(ex);
		}
	}
	private void displayDatacenter(GuiUserEvent event, long dcId) {
	   try {
			event.window.cursorWait();
			JDataSet dsDc = srv.getDatacenter(dcId);
			dsDc.setUsername(this.loginUser);
			event.window.reset();
			event.window.setDatasetValues(dsDc);
			win.setActionState(GuiWindow.STATE_OLD);
			this.dcSynchron(event);
			event.window.cursorDefault();
		} catch (Exception ex) {
			event.window.cursorDefault();
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * CheckBox "synchron" wird bet�tigt oder Fenster ge�ffnet
	 * @param event
	 */
	public void dcSynchron(GuiUserEvent event) {
		GuiWindow win = event.window;
		this.responseActive(win);
	}
	private void responseActive(GuiWindow win) {
		boolean b =
			!Convert.toBoolean(
				win.getGuiComponent("param.synchron").getValue());
		win.getMainPanel().getGuiComponent("param.responseURL").setEnabled(b);
		win.getMainPanel().getGuiComponent("param.cmbResponseTrans").setEnabled(b);
		win.getMainPanel().getGuiComponent("param.cmbResponseEncoding").setEnabled(b);
		win.getMainPanel().getGuiComponent("param.cmbResponseCodecs").setEnabled(b);
		win.getMainPanel().getGuiComponent("param.responseUsername").setEnabled(b);
		win.getMainPanel().getGuiComponent("param.responsePassword").setEnabled(b);
	}
	/**
	 * Rechenzentrum: Pflege der PLZ zu einem Ort
	 * @param event
	 */
	public final void plzOrt(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiDialog dia = (GuiDialog) fact.createWindow("CityZIP.xml");
			dia.setController(new CityZIPPriceController());
			// 2. Attribut "element=" der Tabelle setzen
			int num =
				event.window.getRootPane().getCurrentTable().getSelectedRow();
			String eleName = ".City[" + Convert.toString(num) + "].PostalCode";
			GuiComponent tblZIP = dia.getGuiComponent("postalCode");
			tblZIP.setElementName(eleName);
			// 3 Ort und AGS f�r neue Zeilen versorgen
			GuiTableRow trow =
				event.window.getRootPane().getCurrentTable().getRow(num);
			dia.setValue("cityName", trow.getValue("cityName"));
			dia.setValue("cityId", trow.getValue("cityId"));
			// 4. Daten aus Hauptfenster umt�ten
			JDataSet ds = event.window.getDatasetValues();
			dia.setDatasetValues(ds);
			// 5. Anzeigen
			if (dia.showDialog()) {
				// 6. Zur�ckt�ten
				JDataSet dsDia = dia.getDatasetValues();
				event.window.setDatasetValues(dsDia);
			}
		} catch (Exception ex) {
			logger.error("PLZ/Ort", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * Rechenzentrum: Preise mit G�ltigkeitszeitpunkt eingeben
	 * @param event
	 */
	public final void preisGueltig(GuiUserEvent event) {
		// Preise eingeben
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiDialog dia =
				(GuiDialog) fact.createWindow("CityPrice.xml");
			dia.setController(new CityZIPPriceController());
			// 2. Attribut "element=" der Tabelle setzen
			int num =
				event.window.getRootPane().getCurrentTable().getSelectedRow();
			String eleName = ".City[" + Convert.toString(num) + "].CityPrice";
			GuiComponent tblPrice = dia.getGuiComponent("price");
			tblPrice.setElementName(eleName);
			// 3 AGS f�r neue Zeilen versorgen
			GuiTableRow trow =
				event.window.getRootPane().getCurrentTable().getRow(num);
			dia.setValue("cityName", trow.getValue("cityName"));
			dia.setValue("cityId", trow.getValue("cityId"));
			// 4. Daten aus Hauptfenster umt�ten
			JDataSet ds = event.window.getDatasetValues();
			dia.setDatasetValues(ds);
			// 5. Anzeigen
			if (dia.showDialog()) {
				// 6. Zur�ckt�ten
				JDataSet dsDia = dia.getDatasetValues();
				event.window.setDatasetValues(dsDia);
			}
		} catch (Exception ex) {
			logger.error("City/Price", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * Speichert das Rechenzentrum, deren Mitarbeiter, die Transaktionskosten 
	 * sowie die zugewiesenen Orte und deren Verwaltungsgeb�hr.
	 * @param event
	 */
	public final void saveDC(GuiUserEvent event) {
		try {
			GuiWindow window = event.window;
			JDataSet ds = window.getDatasetValues();
			
			// Orte
			JDataRow dcRow = ds.getRow();
			long dcid = dcRow.getValueLong("DcId");
			Iterator it = dcRow.getChildRows("City");
			if (it != null) {
				while (it.hasNext()) {
					JDataRow row = (JDataRow) it.next();
					if (row.isInserted()) {
						// Diese Gymnastik dient dazu, da� statt einem INSERT
						// der PL ein UPDATE macht
						// Nach Trick 17 nun Trick 18: VERSION setzen, damit Update klappt 
						City city = srv.getCity(row.getValueLong("CityId"));
						row.setValue("Version", city.getVersion());
						//tblCity.
						row.commitChanges();
						row.setValue("dcid", dcid);
					} else {
						if (row.isDeleted()) {
							row.setDeleted(false);
							row.setValue("dcid", (String) null);
						}
					}
				}
			}
			// End Orte
			if (ds.hasChanges()) {
				event.window.cursorWait();
				JDataSet dsChanges = ds.getChanges();
				event.window.verify();
				boolean b = ds.verify();
				if (!b) {
				   String s = ds.getValidationError();
				   GuiUtil.showMessage(event.window, "Validation Error", "Error", s);
				   return;
				}
				srv.setDatacenter(dsChanges);
				window.commitChanges();
				ds.commitChanges();
				win.setActionState(GuiWindow.STATE_SAVED);
				event.window.cursorDefault();
			}
		} catch (Exception ex) {
			event.window.cursorDefault();
			logger.error("Save Datacenter", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * Erzeugt ein neues Rechenzentrum.
	 * @param event
	 */
	public final void newDC(GuiUserEvent event) {
		try {
			GuiWindow window = event.window;
			window.reset();
			DataCenter dc = srv.newDatacenter();
			dc.setDatasetUsername(this.loginUser);
			JDataSet ds = dc.getDataSet();
			window.setDatasetValues(ds);
			win.setActionState(GuiWindow.STATE_NEW);
		} catch (Exception ex) {
			logger.error("New Datacenter", ex);
			GuiUtil.showEx(ex);
		}
	}
}
