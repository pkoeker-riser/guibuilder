/*
 * Created on 02.03.2005
 */
package de.psi.ema.client.intern;

import de.guibuilder.framework.GuiCombo;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;

import de.jdataset.JDataSet;
import de.jdataset.ParameterList;
import de.pkjs.util.Convert;

import de.psi.ema.clientif.InternalClientIF;

/**
 * Controller f�r InternalClientLog.xml
 * @author PKOEKER
 */
public class InternalLogController {
	private static InternalLogController me;
	private GuiFactory fact;
	private GuiWindow win;
	private InternalClientIF srv;

	private static org.apache.log4j.Logger logger =
		org.apache.log4j.Logger.getLogger(InternalLogController.class);
	
	// private Constructor
	private InternalLogController() throws Exception {
		fact = GuiFactory.getInstance();
		// Services
		srv = ClientSession.getInstance().getInternalService();
	}
	static synchronized void startup() throws Exception {
		if (me == null) {
			me = new InternalLogController();
		}
		me.guiInit();
	}
	private void guiInit() throws Exception {
		win = fact.createWindow("InternalClientLog.xml");
		win.setController(this);
		// ComboBox Customer mit Werten f�llen
		GuiCombo cmbUser = (GuiCombo)win.getGuiComponent("cmbUser");
		JDataSet dsUser = srv.getInternalUsers();
		cmbUser.setItems(dsUser);
		win.reset();
		win.show();
	}
	public final void getInternalClientLog(GuiUserEvent event) {
		String[] names = new String[]{"cmbUser", "fromDate", "toDate", "method"};
		ParameterList list = new ParameterList();
		String sql = "SELECT * FROM InternalClientLog";
		sql = sql + " WHERE ";
		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			String val = win.getValue(name).toString();
			String ref = win.getGuiComponent(name).getRef();
			if (val.length() > 0) {
				if (name.equals("fromDate") || name.equals("toDate")) {
					list.addParameter(name, Convert.toDate(val));
				} else {
					list.addParameter(name, val);
				}
				sql = sql + ref + " ? AND "; 
			}
		}
		sql = sql.substring(0, sql.length() -4);
		try {
			JDataSet ds = srv.getInternalUserLog(sql, list);
			event.window.setDatasetValues(ds);
		} catch (Exception ex) {
			GuiUtil.showEx(ex);
		}
	}
	public final void clearInternalClientLog(GuiUserEvent event) {
		event.window.reset();
	}
}
