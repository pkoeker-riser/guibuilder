/*
 * Created on 27.01.2005
 */
package de.psi.ema.client.intern;

import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiTableRow;

import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.GuiUserEvent;
import de.psi.ema.clientif.InternalClientIF;

/**
 * GuiController f�r CityZIP.xml und CityPrice.xml
 * @author PKOEKER
 */
public final class CityZIPPriceController {
	private GuiFactory fact;
	private GuiWindow win;
	private InternalClientIF srv;
	
	//private String loginUser;

	private static org.apache.log4j.Logger logger =
		org.apache.log4j.Logger.getLogger(CityController.class);

	CityZIPPriceController() {
		//this.loginUser = loginUser;
		this.fact = GuiFactory.getInstance();
		// Services
		this.srv = ClientSession.getInstance().getInternalService();
	}
	public final void insertPrice(GuiUserEvent event) {
		GuiTable tbl = event.window.getRootPane().getCurrentTable();
		Object cityId = event.window.getValue("cityId");
		GuiTableRow trow = tbl.insertRow();
		trow.setValue("cityId", cityId);
	}
	public final void deletePrice(GuiUserEvent event) {
		GuiTable tbl = event.window.getRootPane().getCurrentTable();
		tbl.deleteRow();
	}
	public final void insertZIP(GuiUserEvent event) {
		GuiTable tbl = event.window.getRootPane().getCurrentTable();
		Object cityName = event.window.getValue("cityName");
		Object cityId = event.window.getValue("cityId");
		GuiTableRow trow = tbl.insertRow();
		trow.setValue("cityName", cityName);
		trow.setValue("cityId", cityId);
	}
	public final void deleteZIP(GuiUserEvent event) {
		GuiTable tbl = event.window.getRootPane().getCurrentTable();
		tbl.deleteRow();
	}

}
