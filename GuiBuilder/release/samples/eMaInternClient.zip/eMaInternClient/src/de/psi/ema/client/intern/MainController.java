/*
 * Created on 27.02.2004
 */
package de.psi.ema.client.intern;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;

import psi.pm.file.FileUtils;
import de.guibuilder.framework.GuiCombo;
import de.guibuilder.framework.GuiDialog;
import de.guibuilder.framework.GuiFactory;
import de.guibuilder.framework.GuiForm;
import de.guibuilder.framework.GuiTable;
import de.guibuilder.framework.GuiTableRow;
import de.guibuilder.framework.GuiUtil;
import de.guibuilder.framework.GuiWindow;
import de.guibuilder.framework.event.*;
import de.jdataset.JDataRow;
import de.jdataset.JDataSet;
import de.pkjs.util.Convert;
import de.psi.ema.clientif.DirectoryServiceIF;
import de.psi.ema.clientif.InternalClientIF;
import de.psi.ema.domain.OrderItem;
import de.psi.ema.domain.OrderItemFactory;
import de.psi.ema.util.FormatUtil;
import de.psi.ema.util.eMaCommonBuild;
import de.psi.ema.util.eMaInternClientBuild;
import de.psi.ema.util.eMaServerBuild;
import electric.xml.Document;
import electric.xml.Element;
import electric.xml.XPath;

/**
 * Dialog-Controller f�r das Haupt-Men� des internen Administration Clients.
 * @author pkoeker
 */
public final class MainController {
	private static MainController me;

	private GuiWindow windowAuftrag;

	private GuiWindow windowMain;

	private GuiFactory fact;

	private InternalClientIF srv;

	private DirectoryServiceIF dsrv;

	private String loginUser;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger
			.getLogger(MainController.class);

	// private Constructor
	private MainController() {
		fact = GuiFactory.getInstance();
		srv = ClientSession.getInstance().getInternalService();
		dsrv = ClientSession.getInstance().getDirectoryService();
		this.loginUser = ClientSession.getInstance().getLoginUser();
	}

	static MainController getInstance() {
		if (me == null) {
			synchronized (MainController.class) {
				me = new MainController();
			}
		}
		return me;
	}

	/**
	 * Haupt-Fenster "Main.xml" anzeigen.
	 * 
	 * @param sHost
	 *            SOAP Binding to Host from login
	 */
	void showWindow(ClientSession.ConfigEntry entry) {
		try {
			String sXml = GuiUtil.fileToString("Main.xml");
			// Logo
			Document winDoc = new Document(sXml.getBytes());
			String imgName = entry.image;
			Element label = winDoc.getElement(new XPath("//Label"));
			if (label != null) {
				label.setAttribute("img", imgName);
			}
			windowMain = fact.createWindow(winDoc);
			windowMain.setController(this);
			GuiForm frm = (GuiForm) windowMain;
			GuiCombo myCmb = (GuiCombo) windowMain.getGuiComponent("cmbVersion");
			myCmb.addItem("Version: " + srv.getVersion());
			myCmb.addItem("Server: " + eMaServerBuild.getBuild());
			myCmb.addItem("Common: " + eMaCommonBuild.getBuild());
			myCmb.addItem("Client: " + eMaInternClientBuild.getBuild());
			// Title
			String sTitle = "Internal Administration Client";
			sTitle = entry.title;
			windowMain.setTitle(sTitle + " / Host: " + entry.url);
			windowMain.show();
			Thread.currentThread().join();
		} catch (Exception ex) {
			logger.error("Show Main.xml", ex);
			//ex.printStackTrace();
		}
	}
	/**
	 * Beenden der Anwendung
	 * @param event
	 */
	public final void exitClient(GuiUserEvent event) {
		System.exit(0);
	}

	/**
	 * Startet den Dialogablauf Worker
	 * 
	 * @param event
	 */
	public final void workers(GuiUserEvent event) {
		WorkerController ctrl = new WorkerController(true); // show=true
	}

	/**
	 * Started den Dialogablauf Customer
	 */
	public final void customers(GuiUserEvent event) {
		CustomerController ctrl = new CustomerController(this.loginUser);
	}
	/**
	 * Started den Dialogablauf zur Verwaltung der Rechenzentren
	 * @param event
	 */
	public final void datacenters(GuiUserEvent event) {
		DatacenterController ctrl = new DatacenterController(this.loginUser);
	}
	/** 
	 * Startet den Dialogablauf zur Verwaltung von Gemeinden, deren PLZ und Preisen.
	 * @param event
	 */
	public final void cities(GuiUserEvent event) {
		CityController ctrl = new CityController(this.loginUser);
	}

	/**
	 * Leistungsnachweis Kunde: Suchen nach Kunden
	 * 
	 * @param event
	 */
	public final void findCustomer(GuiUserEvent event) {
		try {
			GuiWindow window = event.window;
			JDataSet ds = srv.getCustomers();
			ds.setUsername(this.loginUser);
			GuiDialog dia = (GuiDialog) fact.createWindow("CustomerOverview.xml");
			dia.setController(this);
			dia.setDatasetValues(ds);
			if (dia.showDialog()) {
				GuiTable tbl = dia.getRootPane().getCurrentTable();
				String custId = tbl.getCellValue(0);
				window.setValue("customerID", custId);
			}
		} catch (Exception ex) {
			logger.error("Search Customer", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * Leistungsnachweis: Suche nach Rechenzentren
	 * @param event
	 */
	public final void findDatacenter(GuiUserEvent event) {
		try {
			GuiWindow window = event.window;
			JDataSet ds = srv.getDatacenters();
			ds.setUsername(this.loginUser);
			GuiDialog dia = (GuiDialog) fact
					.createWindow("DatacenterOverview.xml");
			dia.setController(this);
			dia.setDatasetValues(ds);
			if (dia.showDialog()) {
				GuiTable tbl = dia.getRootPane().getCurrentTable();
				String dcId = tbl.getCellValue(0);
				window.setValue("supplierID", dcId);
			}
		} catch (Exception ex) {
			logger.error("Search Datacenter", ex);
			GuiUtil.showEx(ex);
		}
	}


	// ################## ADMIN #####################
	// Unterbrochene Auftr�ge
	public final void auftragUnterbrochenListe(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact
					.createWindow("AuftragUnterbrochenUebersicht.xml");
			win.setController(this);
			JDataSet ds = srv.getUnterbrocheneAuftraege();
			ds.setUsername(this.loginUser);
			win.setDatasetValues(ds);
			win.show();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragUnterbrochenDetail(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("AuftragUnterbrochenDetail.xml");
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int selRow = tbl.getSelectedRow();
			if (selRow == -1) {
				throw new IllegalStateException("Now Table Row selected!");
			}
			//String auftrag = tbl.getCellValue(selRow, "preId");
			GuiTableRow tRow = tbl.getRow(selRow);
			String auftrag = tRow.getValue("preId").toString();
			long auftragId = Convert.toLong(auftrag);
			win.setController(this);
			JDataSet ds = srv.getUnterbrochenenAuftrag(auftragId);
			ds.setUsername(this.loginUser);
			win.setDatasetValues(ds);
			win.show();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragRetry(GuiUserEvent event) {
		try {
			String sId = event.window.getValue("preId").toString();
			long id = Convert.toLong(sId);
			srv.retryOrder(id, this.loginUser);
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragPosiRetry(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int selRow = tbl.getSelectedRow();
			GuiTableRow tRow = tbl.getRow(selRow);
			String sId = tRow.getValue("preId").toString();
			long id = Convert.toLong(sId);
			srv.retryOrderEntry(id, this.loginUser);
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragError(GuiUserEvent event) {
		try {
			String sId = event.window.getValue("preId").toString();
			long id = Convert.toLong(sId);
			srv.setWaitOrderError(id, this.loginUser);
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragPosiError(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int selRow = tbl.getSelectedRow();
			GuiTableRow tRow = tbl.getRow(selRow);
			String sId = tRow.getValue("preId").toString();
			long id = Convert.toLong(sId);
			srv.setWaitEntryError(id, this.loginUser);
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragRetryMulti(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int rows[] = tbl.getSelectedRows();
			for (int i = 0; i < rows.length; i++) {
				GuiTableRow tRow = tbl.getRow(rows[i]);
				String sId = tRow.getValue("preId").toString();
				long id = Convert.toLong(sId);
				srv.retryOrder(id, this.loginUser);
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragErrorMulti(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int rows[] = tbl.getSelectedRows();
			for (int i = 0; i < rows.length; i++) {
				GuiTableRow tRow = tbl.getRow(rows[i]);
				String sId = tRow.getValue("preId").toString();
				long id = Convert.toLong(sId);
				srv.setWaitOrderError(id, this.loginUser);
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * Siehe AuskunftAuftrag.xml 
	 * @param event
	 */
	public final void auftragSave(GuiUserEvent event) {
		try {
			GuiWindow win = event.window;
			JDataSet ds = win.getDatasetValues();
			if (ds.hasChanges()) {
				JDataSet dsChanges = ds.getChanges();
				int cnt = srv.setOrder(ds);
			}
		} catch (Exception ex) {
			logger.error("Auskunft Auftrag", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void auftragPosiDetail(GuiUserEvent event) {
		try {
			GuiTable tbl = event.window.getRootPane().getCurrentTable();
			int row = tbl.getSelectedRow();
			GuiTableRow tRow = tbl.getRow(row);
			GuiDialog detailWin = (GuiDialog)fact.createWindow("EntryDetail.xml");
			// Vorsicht! Tabelle kann umsortiert werden!
			String eleName = "PRE.PRE_Entry["
					+ Convert.toString(tRow.getModelElementNumber()) + "]";
			detailWin.setRootElementName(eleName);
			JDataSet ds = event.window.getDatasetValues();
			JDataRow rowEntry = ds.getDataRowPath(eleName);
			OrderItem item = OrderItemFactory.getInstance().getOrderItem(ds, rowEntry);
			detailWin.setDatasetValues(ds);
			// Je nach Land
			String country = item.getCountry();
			if (country.equalsIgnoreCase("de")) {
			    detailWin.getGuiContainer("grpAT").setVisible(false);
			    detailWin.getGuiContainer("grpIE").setVisible(false);
			} else if (country.equalsIgnoreCase("at")) {
			    detailWin.getGuiContainer("grpAT").setVisible(true);
			    detailWin.getGuiContainer("grpIE").setVisible(false);
			} else  if (country.equalsIgnoreCase("ie")) {
			    detailWin.getGuiContainer("grpAT").setVisible(false);
			    detailWin.getGuiContainer("grpIE").setVisible(true);
			}
			if (detailWin.showDialog()) {
			    ds = detailWin.getDatasetValues();
			    event.window.setDatasetValues(ds);
			}

		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	/**
	 * Ausstehende Auftragspositionen zeigen
	 * 
	 * @param event
	 */
	public final void outstandingOrders(GuiUserEvent event) {
		OutstandingOrderController ctrl = new OutstandingOrderController(
				this.loginUser);
	}

	// REPORTS ############################
	public final void showCustomereAccounting(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("LeistungsnachweisKunde.xml");
			win.setController(this);
			win.show();
		} catch (Exception ex) {
			logger.error("showCustomereAccounting", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void showDataCenterAccounting(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("LeistungsnachweisRZ.xml");
			win.setController(this);
			win.show();
		} catch (Exception ex) {
			logger.error("showDataCenterAccounting", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void showMunicipalityAccounting(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("LeistungsnachweisKommune.xml");
			win.setController(this);
			win.show();
		} catch (Exception ex) {
			logger.error("showMunicipalityAccounting", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void showDataCenterQuality(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("DatenqualitaetRZ.xml");
			win.setController(this);
			win.show();
		} catch (Exception ex) {
			logger.error("showDataCenterQuality", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void showDataCenterSLA(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiDialog win = (GuiDialog) fact.createWindow("SLA_RZ.xml");
			JDataSet dsDC = srv.getDatacenters();
			dsDC.setUsername(this.loginUser);
			GuiCombo cmb = (GuiCombo) win.getGuiComponent("cmbRZ");
			cmb.setItems(dsDC);
			win.setController(this);
			if (win.showDialog()) {
				try {
					Date from = Convert.toDate(win.getValue("from").toString());
					Date to = Convert.toDate(win.getValue("to").toString());
					long supplierID = Convert.toLong(win.getValue("cmbRZ").toString());
					byte[] pdfData = srv.createSupplierSLAReport(supplierID,
							from, to, false, "");
					if (pdfData != null) {
						String pdfFilename = "DataCenterSLAReport.pdf";
						File f = new File(".");

						String path = FileUtils.extractPath(f.getAbsolutePath());
						path += pdfFilename;
						System.out.println("Path: " + path);
						FileUtils.saveFile(path, new ByteArrayInputStream(pdfData));
						Process p = Runtime.getRuntime().exec(
								"rundll32 " + "url.dll,FileProtocolHandler " + path);
					} else {
						GuiUtil.showMessage(event.window, "Reporting",
								"Fehler",
								"Der Bericht konnte nicht erstellt werden!");
					}
				} catch (Exception ex) {
					logger.error(ex.getMessage(), ex);
					GuiUtil.showEx(ex);
				}
			}
		} catch (Exception ex) {
			logger.error("showDataCenterSLA", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void showTurnover(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("Umsatzstatistik.xml");
			win.setController(this);
			win.show();
		} catch (Exception ex) {
			logger.error("showTurnover", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void showPriceList(GuiUserEvent event) {
		FileWriter fw = null;
		try {
			JDataSet ds = dsrv.getPriceList();
			String s = FormatUtil.dataset2PriceList(ds);
			String path = "c:/temp/ema_preisliste.csv";
			File f = new File(path);
			fw = new FileWriter(f);
			fw.write(s);
			fw.close();
			Process p = Runtime.getRuntime().exec(
					"rundll32 " + "url.dll,FileProtocolHandler " + path);

		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (Exception ex) {
				}
			}
		}
	}

	public final void showPriceListFromTo(GuiUserEvent event) {
		FileWriter fw = null;
		try {
			GuiDialog dia = (GuiDialog) GuiFactory.getInstance().createWindow(
					"PriceList.xml");
			if (dia.showDialog()) {
				long fromAgs = Convert.toLong(dia.getValue("from").toString());
				long toAgs = Convert.toLong(dia.getValue("to").toString());
				JDataSet ds = dsrv.getPriceList(fromAgs, toAgs);
				String s = FormatUtil.dataset2PriceList(ds);
				String path = "c:/temp/ema_preisliste.csv";
				File f = new File(path);
				fw = new FileWriter(f);
				fw.write(s);
				fw.close();
				Process p = Runtime.getRuntime().exec(
						"rundll32 " + "url.dll,FileProtocolHandler " + path);
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (Exception ex) {
				}
			}
		}
	}

	public final void createCustomerAccountingReport(GuiUserEvent event) {
		try {
			Date from = Convert
					.toDate(event.window.getValue("from").toString());
			Date to = Convert.toDate(event.window.getValue("to").toString());
			long customerID = Convert.toLong(event.window
					.getValue("customerID").toString());
			byte[] pdfData = srv.createCustomerAccountingReport(customerID,
					from, to, false, "");
			if (pdfData != null) {
				String pdfFilename = "CustomerAccountingReport.pdf";
				File f = new File(".");
				String path = FileUtils.extractPath(f.getAbsolutePath());
				path += pdfFilename;
				System.out.println("Path: " + path);
				FileUtils.saveFile(path, new ByteArrayInputStream(pdfData));
				Process p = Runtime.getRuntime().exec(
						"rundll32 " + "url.dll, FileProtocolHandler " + path);
			} else {
				GuiUtil.showMessage(event.window, "Reporting", "Fehler",
						"Der Bericht konnte nicht erstellt werden!");
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void createSupplierAccountingReport(GuiUserEvent event) {
		try {
			Date from = Convert
					.toDate(event.window.getValue("from").toString());
			Date to = Convert.toDate(event.window.getValue("to").toString());
			long supplierID = Convert.toLong(event.window
					.getValue("supplierID").toString());
			byte[] pdfData = srv.createSupplierAccountingReport(supplierID,
					from, to, false, "");
			if (pdfData != null) {
				String pdfFilename = "SupplierAccountingReport.pdf";
				File f = new File(".");

				String path = FileUtils.extractPath(f.getAbsolutePath());
				path += pdfFilename;
				System.out.println("Path: " + path);
				FileUtils.saveFile(path, new ByteArrayInputStream(pdfData));
				Process p = Runtime.getRuntime().exec(
						"rundll32 " + "url.dll,FileProtocolHandler " + path);
			} else {
				GuiUtil.showMessage(event.window, "Reporting", "Fehler",
						"Der Bericht konnte nicht erstellt werden!");
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void createMunicipalityAccountingReport(GuiUserEvent event) {
		try {
			Date from = Convert
					.toDate(event.window.getValue("from").toString());
			Date to = Convert.toDate(event.window.getValue("to").toString());
			long cityID = Convert.toLong(event.window.getValue("cityID")
					.toString());
			byte[] pdfData = srv.createMunicipalityAccountingReport(cityID,
					from, to, false, "");
			if (pdfData != null) {
				String pdfFilename = "MunicipalityAccountingReport.pdf";
				File f = new File(".");

				String path = FileUtils.extractPath(f.getAbsolutePath());
				path += pdfFilename;
				System.out.println("Path: " + path);
				FileUtils.saveFile(path, new ByteArrayInputStream(pdfData));
				Process p = Runtime.getRuntime().exec(
						"rundll32 " + "url.dll,FileProtocolHandler " + path);
			} else {
				GuiUtil.showMessage(event.window, "Reporting", "Fehler",
						"Der Bericht konnte nicht erstellt werden!");
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void createDataCenterQualityReport(GuiUserEvent event) {
		try {
			Date from = Convert
					.toDate(event.window.getValue("from").toString());
			Date to = Convert.toDate(event.window.getValue("to").toString());
			long supplierID = Convert.toLong(event.window
					.getValue("supplierID").toString());
			byte[] pdfData = srv.createSupplierDataQualityReport(supplierID,
					from, to, false, "");
			if (pdfData != null) {
				String pdfFilename = "DataCenterQualityReport.pdf";
				File f = new File(".");

				String path = FileUtils.extractPath(f.getAbsolutePath());
				path += pdfFilename;
				System.out.println("Path: " + path);
				FileUtils.saveFile(path, new ByteArrayInputStream(pdfData));
				Process p = Runtime.getRuntime().exec(
						"rundll32 " + "url.dll,FileProtocolHandler " + path);
			} else {
				GuiUtil.showMessage(event.window, "Reporting", "Fehler",
						"Der Bericht konnte nicht erstellt werden!");
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void createTurnoverReport(GuiUserEvent event) {
		try {
			Date from = Convert
					.toDate(event.window.getValue("from").toString());
			Date to = Convert.toDate(event.window.getValue("to").toString());
			boolean isAnonym = Convert.toBoolean(event.window.getValue(
					"isAnonym").toString());
			String pdfFilename = "TurnoverReport.pdf";
			byte[] pdfData = srv.createTurnoverReport(from, to, false,
					pdfFilename, isAnonym);
			if (pdfData != null) {

				File f = new File(".");

				String path = FileUtils.extractPath(f.getAbsolutePath());
				path += pdfFilename;
				System.out.println("Path: " + path);
				FileUtils.saveFile(path, new ByteArrayInputStream(pdfData));
				Process p = Runtime.getRuntime().exec(
						"rundll32 " + "url.dll,FileProtocolHandler " + path);
			} else {
				GuiUtil.showMessage(event.window, "Reporting", "Fehler",
						"Der Bericht konnte nicht erstellt werden!");
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	// ACCOUNTING #########################
	public final void showAccounting(GuiUserEvent event) {
		try {
			// 1. Dialog erzeugen / Controller registrieren
			GuiWindow win = fact.createWindow("CreateAccounting.xml");
			win.setController(this);
			win.show();
		} catch (Exception ex) {
			logger.error("Accounting", ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void createAccountingData(GuiUserEvent event) {
		Date vonDatum = Convert.toDate(event.window.getValue("vonDatum").toString());
		Date bisDatum = Convert.toDate(event.window.getValue("bisDatum").toString());
		try {
			int cnt = srv.createAccountingData(vonDatum, bisDatum, this.loginUser);
			GuiUtil.showMessage(event.window, "Accounting", "Info",
					"Anzahl der erzeugten Datens�tze: " + cnt);

		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	public final void accountingDatumGeandert(GuiUserEvent event) {
		Date vonDatum = Convert.toDate(event.window.getValue("vonDatum").toString());
		Date bisDatum = Convert.toDate(event.window.getValue("bisDatum").toString());
		if (vonDatum == null || bisDatum == null) {
			event.window.getAction("execute").setEnabled(false);
		} else {
			int comp = vonDatum.compareTo(bisDatum);
			if (comp == 1) {
				event.window.getAction("execute").setEnabled(false);
			} else {
				event.window.getAction("execute").setEnabled(true);
			}
		}
	}

	// Auskunft Auftrag #################################
	public final void auskunftAuftrag(GuiUserEvent event) {
		try {
			GuiWindow win = this.showAuskunftAuftrag();
		} catch (Exception ex) {
			logger.error("Auskunft Auftrag", ex);
			GuiUtil.showEx(ex);
		}
	}

	private GuiWindow showAuskunftAuftrag() throws Exception {
		windowAuftrag = this.fact.createWindow("AuskunftAuftrag.xml");
		windowAuftrag.setController(this);
		windowAuftrag.show();
		return windowAuftrag;
	}

	GuiWindow showAuskunftAuftrag(long orderId) throws Exception {
		windowAuftrag = this.fact.createWindow("AuskunftAuftrag.xml");
		windowAuftrag.setController(this);
		windowAuftrag.setValue("preid", Convert.toString(orderId));
		windowAuftrag.doAction("pbOrder");
		windowAuftrag.show();
		return windowAuftrag;
	}
	/**
	 * Lesen eines Auftrags �ber Auftragsnummer
	 * @param event
	 */
	public final void auftragLoad(GuiUserEvent event) {
		try {
			GuiWindow win = event.window;
			Object obj = win.getValue("preid");
			if (obj == null) {
				showErrorMsgBox(windowAuftrag, "Die Auftragsnummer muss eine Zahl sein!");
				return;
			}
			String value = obj.toString();
			if (value == null || value.length() == 0) {
				showErrorMsgBox(windowAuftrag,
						"Bitte zuerst die Auftragsnummer eingeben!");
				return;
			}

			long preId = -1;
			try {
				preId = Long.parseLong(value);
				JDataSet ds = srv.getOrder(preId);
				if (ds.getRowCount() == 0) {
					showInfoMsgBox(windowAuftrag,
							"Der Auftrag ist nicht vorhanden!");
					win.getAction("reload").setEnabled(false);
				} else {
					win.setDatasetValues(ds);
					win.getAction("reload").setEnabled(true);
				}
			} catch (NumberFormatException ex) {
				showErrorMsgBox(windowAuftrag,
						"Die Auftragsnummer muss eine Zahl sein!");
			}

		} catch (Exception ex) {
			logger.error("Auskunft Auftrag", ex);
			GuiUtil.showEx(ex);
		}
	}
	/**
	 * Lesen eines Auftrags �ber eine Positionsnummer
	 * @param event
	 */
	public final void auftragPosiLoad(GuiUserEvent event) {
		try {
			GuiWindow win = event.window;
			Object obj = win.getValue("preid");
			if (obj == null) {
				showErrorMsgBox(windowAuftrag, "Die Auftragsnummer muss eine Zahl sein!");
				return;
			}

			String value = obj.toString();
			if (value == null || value.length() == 0) {
				showErrorMsgBox(windowAuftrag, "Bitte zuerst die Auftragsnummer eingeben!");
				return;
			}

			long entryId = -1;
			try {
				entryId = Long.parseLong(value);
				JDataSet ds = srv.getOrderByEntryId(entryId);
				if (ds == null || ds.getRowCount() == 0) {
					showInfoMsgBox(windowAuftrag,
							"Der Auftrag ist nicht vorhanden!");
					win.getAction("reload").setEnabled(false);
				} else {
					win.setDatasetValues(ds);
					win.getAction("reload").setEnabled(true);
				}
			} catch (NumberFormatException ex) {
				showErrorMsgBox(windowAuftrag, "Die Auftragsnummer muss eine Zahl sein!");
			}

		} catch (Exception ex) {
			logger.error("Auskunft Auftrag", ex);
			GuiUtil.showEx(ex);
		}
	}

	private void showInfoMsgBox(GuiWindow window, String msg) {
		GuiUtil.showMessage(window, "Internal Client", "Info", msg);
	}

	private void showErrorMsgBox(GuiWindow window, String msg) {
		GuiUtil.showMessage(window, "Internal Client", "Error", msg);
	}
	public final void xMeld2TLD(GuiUserEvent event) {
		try {
			GuiDialog win = (GuiDialog) fact.createWindow("XMeldCountry.xml");
			win.setController(this);
			JDataSet ds = this.dsrv.getXMeld2TLD();
			ds.setUsername(this.loginUser);
			win.setDatasetValues(ds);
			if (win.showDialog()) {
				ds = win.getDatasetValues();
				this.dsrv.setXMeldTLD(ds);
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			throw new IllegalStateException(ex.getMessage());
		}
	}

	// ################## Internal Users ######################
	/**
	 * Zeigt alle internen User an; siehe 'InternalUsers.xml'
	 */
	public final void showInternalUsers(GuiUserEvent event) {
	   InternalUserController ctrl = new InternalUserController(this.loginUser);
	}

	// #### LOGGING #####################################################
	public final void showCustomerLog(GuiUserEvent event) {
		try {
			CustomerLogController.startup();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}
	public final void showInternalLog(GuiUserEvent event) {
		try {
			InternalLogController.startup();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	// ##############
	public final void writeMetadata(GuiUserEvent event) {
		try {
			srv.writeDatabaseMetadata();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			GuiUtil.showEx(ex);
		}
	}

	// ######### Corrections ########################
	public final void x_korrRegis24Cityid(GuiUserEvent event) {
		try {
			int cnt = srv.x_regis24cityid();
		} catch (Exception ex) {
			GuiUtil.showEx(ex);
		}
	}

	public final void x_importCityPrices(GuiUserEvent event) {
		try {
			ImportCityPriceController ctrl = ImportCityPriceController.getInstance();
			ctrl.show();
		} catch (Exception ex) {
			GuiUtil.showEx(ex);
		}
	}

	public final void EmplKeyTyped(GuiUserEvent event) {
		//Toolkit.getDefaultToolkit().beep();
		GuiKeyEvent ke = (GuiKeyEvent) event;
		int i = 0;
	}
}